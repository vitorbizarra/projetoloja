package projetoloja;

public class ProjetoLoja {

    public static void main(String[] args) {

    }
    
}
